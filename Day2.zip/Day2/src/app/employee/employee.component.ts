import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employee={"id":1,"name":"Nishant"};
  person:any[]=[
    {name:"Swati",country:"India"},
    {name:"John",country:"UK"},
    {name:"Smith",country:"US"}
  ]
getColor(country){

}
employees:any[];
  constructor() {
    this.employees=[
      {id:101,name:"amol pathak",salary:12342,city:"Pune",age:23,gender:1,
       dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"9158652623"},
  
       {id:322,name:"sachin kale",salary:123332.44554,city:"Mumbai",age:43,gender:1,
       dob:new Date("June 31,1989"),pan:"AXAM98345E",mobile:"8158652625"},
  
       {id:133,name:"sunil kadam",salary:112242.44554,city:"Banglore",age:53,gender:1,
       dob:new Date("July 31,1992"),pan:"FCXAM9834M",mobile:"7158652627"},
  
       {id:432,name:"mahesh jadhav",salary:32342.44554,city:"Solapur",age:43,gender:1,
       dob:new Date("July 31,1981"),pan:"CCXAM9834O",mobile:"7758652626"},
  
       {id:453,name:"Pradeep Chinchole",salary:12342.44554,city:"Mumbai",age:13,gender:1,
       dob:new Date("July 31,1972"),pan:"HCXAM9834E",mobile:"9158652626"},
  
       {id:422,name:"Vrushali Nagarkar",salary:44232342.44554,city:"Pune",age:43,gender:2,
       dob:new Date("July 31,1974"),pan:"GCXAM9834M",mobile:"8858652623"},
  
       {id:431,name:"Prachitee Joshi",salary:4432342.44554,city:"Nagpur",age:33,gender:2,
       dob:new Date("July 31,1985"),pan:"YCXAM9834X",mobile:"8758652622"},
  
       {id:454,name:"Mohan Patil",salary:545342.44554,city:"Pune",age:32,gender:1,
       dob:new Date("July 31,1982"),pan:"PXAM98345D",mobile:"8558652629"}
     ]
   }

  ngOnInit(): void {
  }
  updateEmployeeDetails(){
    this.employees=[
      {id:101,name:"amol pathak",salary:12342,city:"Pune",age:23,gender:1,
       dob:new Date("May 31,1982"),pan:"pcxam9834D",mobile:"9158652623"},
  
       {id:322,name:"sachin kale",salary:123332.44554,city:"Mumbai",age:43,gender:1,
       dob:new Date("June 31,1989"),pan:"AXAM98345E",mobile:"8158652625"},
  
       {id:133,name:"sunil kadam",salary:112242.44554,city:"Banglore",age:53,gender:1,
       dob:new Date("July 31,1992"),pan:"FCXAM9834M",mobile:"7158652627"},
  
       {id:432,name:"mahesh jadhav",salary:32342.44554,city:"Solapur",age:43,gender:1,
       dob:new Date("July 31,1981"),pan:"CCXAM9834O",mobile:"7758652626"},
  
       {id:453,name:"Pradeep Chinchole",salary:12342.44554,city:"Mumbai",age:13,gender:1,
       dob:new Date("July 31,1972"),pan:"HCXAM9834E",mobile:"9158652626"},
  
       {id:422,name:"Vrushali Nagarkar",salary:44232342.44554,city:"Pune",age:43,gender:2,
       dob:new Date("July 31,1974"),pan:"GCXAM9834M",mobile:"8858652623"},
  
       {id:431,name:"Prachitee Joshi",salary:4432342.44554,city:"Nagpur",age:33,gender:2,
       dob:new Date("July 31,1985"),pan:"YCXAM9834X",mobile:"8758652622"},
  
       {id:454,name:"Mohan Patil",salary:545342.44554,city:"Pune",age:32,gender:1,
       dob:new Date("July 31,1982"),pan:"PXAM98345D",mobile:"8558652629"},
       {id:455,name:"Sanket Patil",salary:545342.44554,city:"Pune",age:32,gender:1,
       dob:new Date("July 31,1982"),pan:"PXAM98345D",mobile:"8558652629"},
       {id:456,name:"Sunita Patel",salary:545342.44554,city:"Pune",age:32,gender:2,
       dob:new Date("July 31,1982"),pan:"PXAM98345D",mobile:"8558652629"}
     ]
  }
  trackByEmpId(index:number,employee:any):number{
    return employee.id;
  }
}
