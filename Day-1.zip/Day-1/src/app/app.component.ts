import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //template:'<h1>{{title}}</h1>',
 /* template:`<h1>
  {{title}}<br/>
  {{fname}}
  </h1>`,*/
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'First Angular App';
  fname:string="Swati";
  lname:string="Bhirud";
  fullName="";
  show=true;
  getFullName(){
    this.fullName=this.fname+" "+this.lname;
  }
}

