export interface IEmployee{
    id:number;
    name:string;
    city:string;
    salary:number;
    age:number;
    gender:string;
    dob:Date;
    pan:string;
    mobile:string;
}