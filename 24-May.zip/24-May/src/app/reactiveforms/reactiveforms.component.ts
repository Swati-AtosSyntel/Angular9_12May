import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-reactiveforms',
  templateUrl: './reactiveforms.component.html',
  styleUrls: ['./reactiveforms.component.css']
})
export class ReactiveformsComponent implements OnInit {
emailid;
formdata;
  constructor() { }

  ngOnInit(): void {
    this.formdata=new FormGroup({
      emailid:new FormControl("Swati.Bhirud@atos.net"),
      password:new FormControl("xyz123445")
    });
  }
  onSubmit(data){
    this.emailid=data.emailid;
  }

}
