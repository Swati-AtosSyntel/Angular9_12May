import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { GenderPipe } from './gender.pipe';
import { EmployeecountComponent } from './employeecount/employeecount.component';
import {HttpClientModule} from '@angular/common/http';
import { HttpclientexampleComponent } from './httpclientexample/httpclientexample.component';
import { TemplateformComponent } from './templateform/templateform.component';
import { ReactiveformsComponent } from './reactiveforms/reactiveforms.component';
import { Reactiveforms1Component } from './reactiveforms1/reactiveforms1.component';
import { Reactiveforms2Component } from './reactiveforms2/reactiveforms2.component';
import {PagenotfoundComponent} from './pagenotfound/pagenotfound.component';
const routes:Routes=[
{path:'employee',component:EmployeeComponent},
{path:'repository',component:HttpclientexampleComponent},
{path:'',redirectTo:'/employee', pathMatch:'full'},
{path:'**',component:PagenotfoundComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    GenderPipe,
    EmployeecountComponent,
    HttpclientexampleComponent,
    TemplateformComponent,
    ReactiveformsComponent,
    Reactiveforms1Component,
    Reactiveforms2Component,
    PagenotfoundComponent
  ],
  imports: [
ReactiveFormsModule,
BrowserModule,FormsModule,HttpClientModule,
RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
