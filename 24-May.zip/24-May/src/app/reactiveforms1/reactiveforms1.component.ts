import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { kMaxLength } from 'buffer';

@Component({
  selector: 'app-reactiveforms1',
  templateUrl: './reactiveforms1.component.html',
  styleUrls: ['./reactiveforms1.component.css']
})
export class Reactiveforms1Component implements OnInit {
userForm;
  constructor(private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.userForm=new FormGroup({
      fname:new FormControl("Swati",[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
      email:new FormControl(null,Validators.pattern('[^@]*@[^@]*')),
      address:new FormGroup({
        Country:new FormControl(),
        City:new FormControl(),
        pincode:new FormControl(null,Validators.pattern('[1-9][0-9]{4}$'))

      })
    });
    // this.userForm=this.formBuilder.group({
    //   fname:['',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]],
    //  email:[''],
    //  address:this.formBuilder.group({
    //    country:[''],
    //    city:['']

    //  }) 
    // });

  }
  
  // contryList:country[]=[
  //   new country("1","India"),
  //   new country("1","USA")
  // ]
  
  submitForm()
  {
   // console.log(this.userForm.value);
  }

}
export class country{
  id:string;name:string;
  constructor(id:string,name:string){
    this.id=id;
    this.name=name;
  }
}