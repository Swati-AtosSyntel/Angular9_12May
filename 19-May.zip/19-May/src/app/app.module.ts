import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { GenderPipe } from './gender.pipe';
import { EmployeecountComponent } from './employeecount/employeecount.component';
import {HttpClientModule} from '@angular/common/http';
import { HttpclientexampleComponent } from './httpclientexample/httpclientexample.component';
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    GenderPipe,
    EmployeecountComponent,
    HttpclientexampleComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
